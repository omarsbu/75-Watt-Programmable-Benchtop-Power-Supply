Analog Devices Inc.
Design Support Package
CN-0508
05/27/2020
Rev. A


This file is designed to provide you with a brief overview of what is contained within the circuit note design support package.


**********************
*******Overview*******
**********************


CN-0508 Design Support Package contains: 
	
	Link to Circuit Note
	Link to Product Datasheets
	Link to Product Evaluation Boards and User Guides
	Cadence Schematics
	Bill of Materials
	Cadence Layout Files
	Gerber Layout Files
	LTSpice Simulation	
	Link to Symbols and Footprints
	Link to Technical Support
	Link to Other Resources



**********************
***File Explanation**
**********************


Circuit Note - Copy of the circuit note this design support package was made for.  This file is provided as a PDF:

	CN0370: http://www.analog.com/CN0508


Product Datasheets - Links to all ADI component datasheets used in the circuit.  These files are provided as a PDF:
	
	LT8612	 :	http://www.analog.com/LT8612
	LT3081   :	http://www.analog.com/LT3081
	LT8609   :	http://www.analog.com/LT8609
	LTC1983	 :	http://www.analog.com/LTC1983
	AD5683R  :	http://www.analog.com/AD5683R
	LT6015S  :	http://www.analog.com/LT6015
	AD7124-4 :	http://www.analog.com/AD7124-4
	ADCMP392 :	http://www.analog.com/ADCMP392

CN0508 	Evaluation Board:
	 
	EVAL-CN0508-RPIZ: http://www.analog.com/EVAL-CN0508-RPIZ


User Guide for CN0508:

	https://wiki.analog.com/resources/eval/user-guides/circuits-from-the-lab/cn0508
	

Bill of Materials for EVAL-CN0508-RPIZ:

	
	EVAL-CN0508-RPIZ-BOM.xlsx

Schematic Drawings (CADENCE) for EVAL-CN0508-RPIZ:


	EVAL-CN0508-RPIZ-CadenceSchematic.pdf


Layout Drawings (CADENCE) for EVAL-CN0508-RPIZ:


	EVAL-CN0508-RPIZ-CadenceLayout.pdf
	EVAL-CN0508-RPIZ-CadenceLayout.brd
	
	
Gerber Layout Files:


	EVAL-CN0508-RPIZ-GRB.zip
	
	
Symbols and Footprints:

LT8612:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/LT8612.html

	 
LT3081:	
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/LT3081.html


LT8609:	
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/LT8609.html

LTC1983:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/LTC1983.html

	 
AD5683R:	
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/AD5683R.html


LT6015S:	
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/LT6015.html

AD7124-4:	
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/AD7124-4.html


ADCMP392:	
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/ADCMP392.html

Technical Support -  If you require further technical assistance please contact us by phone, email, or our EngineerZone community.  http://www.analog.com/en/content/technical_support_page/fca.html



**********************
***Other Resources****
**********************


Resources that are not provided by Analog Devices, but could be helpful.


Gerber Viewer:  http://www.graphicode.com

PADs Viewer: http://www.mentor.com/products/pcb-system-design/design-flows/pads/pads-pcb-viewer

Allegro Physical Viewer: http://www.cadence.com/products/pcb/Pages/downloads.aspx


